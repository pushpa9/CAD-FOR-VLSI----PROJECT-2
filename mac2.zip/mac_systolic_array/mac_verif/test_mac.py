import os
from pathlib import Path
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, Timer
from model_mac import *

def pack_vector(vector, bit_width):
    packed = 0
    for value in vector:
        packed = (packed << bit_width) | (value & ((1 << bit_width) - 1))
    return packed
    
def unpack_vector(packed, bit_width, num_elements):
    mask = (1 << bit_width) - 1
    return [(packed >> (bit_width * i)) & mask for i in range(num_elements - 1, -1, -1)]


A = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 1, 2, 3],
    [4, 5, 6, 7]
]

B = [
    [1, 2, 3, 4],
    [5, 6, 7, 8],
    [9, 1, 2, 3],
    [4, 5, 6, 7]
]

Result = [
         [54, 37, 47, 57],
         [130, 93, 119, 145],
         [44, 41, 56, 71],
         [111, 79, 101, 123]
]
 
@cocotb.test()
async def test_mac(dut):
    """Test to check MAC operation"""

    dut.EN_get_A.value = 0
    dut.EN_get_B.value = 0
    dut.EN_get_C.value = 0
    dut.EN_s1_or_s2.value = 0
    dut.EN_out_result.value = 0
    
    clock = Clock(dut.CLK, 10, units="us")  # Create a 10us period clock on port clk
    cocotb.start_soon(clock.start(start_high=False))   
    dut.RST_N.value = 0
    await RisingEdge(dut.CLK)
    dut.RST_N.value = 1
    
    dut.EN_get_A.value = 1
    dut.EN_get_B.value = 1
    dut.EN_get_C.value = 1
    dut.EN_s1_or_s2.value = 1
    dut.EN_out_result.value = 1
    
    dut.get_A_x.value = pack_vector([0, 0, 0, 0], 16)
    dut.get_B_y.value = pack_vector([0, 0, 0, 0], 16)
    dut.get_C_z.value = pack_vector([0, 0, 0, 0], 32)
    dut.s1_or_s2_tcs.value = 1
    await RisingEdge(dut.CLK)
    dut._log.info(f'S = {dut.s1_or_s2_tcs.value}')  
    
    # Perform mac1 operation when s == 1
    if dut.s1_or_s2_tcs.value == 1:
        dut._log.info('Performing mac1')
        
        for i in range(0,4):
            dut.get_B_y.value = pack_vector(B[3-i])
            await RisingEdge(dut.CLK)
            dut._log.info(f"DUT output = {int(dut.out_result.value)}")

        dut.get_A_x.value = pack_vector([A[0][0], 0, 0, 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[1][0], A[0][1], 0, 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[2][0], A[1][1], A[0][2], 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[3][0], A[2][1], A[1][2], A[0][3], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[3][1], A[2][2], A[1][3], 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[3][2], A[2][3], 0, 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([A[3][3], 0, 0, 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        dut.get_A_x.value = pack_vector([0, 0, 0, 0], 16)
        await RisingEdge(dut.CLK)
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")

        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        dut._log.info(f"DUT output = {int(dut.out_result.value)}")
        
        
        
        
        
